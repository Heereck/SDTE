﻿namespace Exercise3
{
    public class Int
    {
    }
}